<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '[HccnKsM~ X%Y6NNI.PPitO9*f*/wOh3K75gc1w6;Y+x6{#}rm#y26ec8a{3Bhq+' );
define( 'SECURE_AUTH_KEY',   'om]$d$7Z+w7LTjA~V~eYN* ,2DfF~?(#qV_YfS&SwBzq/[ZtkLklSQw.*ET{s;7P' );
define( 'LOGGED_IN_KEY',     '=7/Qv>qUD/rD2T<4Wj^tUuLN>#6-Xx/ip5YDVj;G(3CYF=0T^ar-u#md;[|OE+~a' );
define( 'NONCE_KEY',         'a:Cr2 SU~CUYd+6y{@O_T2+-xOTbwr7G5l6Cv9Stcwz[;Jive~zxn[=8L1qy WvB' );
define( 'AUTH_SALT',         '.gF<nyl3L&1*XR_FE?Wg2IW0O#p)s+.3L>I!#XVPpRM2UO&i{uOQ9q(W+eXy>E]i' );
define( 'SECURE_AUTH_SALT',  'ZQp>N.y;hB6uUzyz?/+SY1-xoBJa5hbT`.iFN6z;Efv92B{~~Wx[43RQP.$0p-,K' );
define( 'LOGGED_IN_SALT',    ' yU WVoE#V<lYYxX&:@Qjt9YfMnioD,F|$l.JAz[)Ouekm<+B?fZt#+)|@RH>nk!' );
define( 'NONCE_SALT',        'Z/c.+zG~3!r/r-.FOvJ8)XfnfOJl=ME83SU0v {:#}LW3cUGF1bI;.9^!MT=u]B0' );
define( 'WP_CACHE_KEY_SALT', '.CC%fJ5v^%%xJ4q/4XlZu(>Q~n)RlM4p*-uGuOs~jl!xhEd4]+9ynk];).>S%M1m' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
